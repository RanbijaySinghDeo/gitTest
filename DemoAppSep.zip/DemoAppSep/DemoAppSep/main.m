//
//  main.m
//  DemoAppSep
//
//  Created by RanbijaySinghDeo on 03/09/15.
//  Copyright (c) 2015 RanbijaySinghDeo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
