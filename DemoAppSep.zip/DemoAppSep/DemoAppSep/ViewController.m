 //
//  ViewController.m
//  DemoAppSep
//
//  Created by RanbijaySinghDeo on 03/09/15.
//  Copyright (c) 2015 RanbijaySinghDeo. All rights reserved.
//

#import "ViewController.h"
#import "MapViewController.h"
#import <Google/SignIn.h>

@interface ViewController ()<FBSDKLoginButtonDelegate,GIDSignInUIDelegate,GIDSignInDelegate>{
    FBSDKLoginButton *fbLogingButton;
    GIDSignInButton *googleSignInButton;
    MapViewController *mapViewController;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    fbLogingButton = [[FBSDKLoginButton alloc]init];
    fbLogingButton.delegate = self;
    fbLogingButton.center = self.view.center;
    [self.view addSubview:fbLogingButton];
    fbLogingButton.readPermissions =
    @[@"public_profile", @"email", @"user_friends"];
    

    
//    googleSignInButton = [[GIDSignInButton alloc]initWithFrame:CGRectMake(120, 370,50, 150)];
//    [self.view addSubview:googleSignInButton];
    
    
//    [GIDSignIn sharedInstance].uiDelegate = self;
//    [GIDSignIn sharedInstance].delegate = self;

    // Do any additional setup after loading the view, typically from a nib.
}
-(void)viewWillAppear:(BOOL)animated{
    fbLogingButton.hidden = NO;
}
-(void)viewWillDisappear:(BOOL)animated{
    fbLogingButton.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)  loginButton:(FBSDKLoginButton *)loginButton
didCompleteWithResult:(FBSDKLoginManagerLoginResult *)result
                error:(NSError *)error{
    
     mapViewController = [[MapViewController alloc]initWithNibName:@"MapViewController" bundle:nil];
  
    
    [self.navigationController pushViewController:mapViewController animated:YES];
  
   
    NSLog(@"Logged in");
    
}
- (void)signIn:(GIDSignIn *)signIn
didSignInForUser:(GIDGoogleUser *)user
     withError:(NSError *)error {
    mapViewController = [[MapViewController alloc]initWithNibName:@"MapViewController" bundle:nil];
    NSLog(@"%@",user.profile);
    [self.navigationController pushViewController:mapViewController animated:YES];
    // Perform any operations on signed in user here.
    // ...
    
}

- (void)loginButtonDidLogOut:(FBSDKLoginButton *)loginButton{
    
}
- (IBAction)didTapSignOut:(id)sender {
    [[GIDSignIn sharedInstance] signOut];
}

- (void)signInWillDispatch:(GIDSignIn *)signIn error:(NSError *)error {
//    [myActivityIndicator stopAnimating];
}

// Present a view that prompts the user to sign in with Google
- (void)signIn:(GIDSignIn *)signIn
presentViewController:(UIViewController *)viewController {
    [self presentViewController:viewController animated:YES completion:nil];
}

// Dismiss the "Sign in with Google" view
- (void)signIn:(GIDSignIn *)signIn
dismissViewController:(UIViewController *)viewController {
    [self dismissViewControllerAnimated:YES completion:nil];
}


@end
