//
//  SideMenuViewController.m
//  DemoAppSep
//
//  Created by RanbijaySinghDeo on 04/09/15.
//  Copyright (c) 2015 RanbijaySinghDeo. All rights reserved.
//

#import "SideMenuViewController.h"
#import "SideMenuTableViewCell.h"
#import <Google/SignIn.h>


@class FBSDKProfilePictureView;

@interface SideMenuViewController (){
    NSArray *viewNameArray;
    NSURL *url;
    NSString *loggedInUserName;
    FBSDKProfilePictureView *pictureView;
    UIImageView *googleImageView;
}

@end

@implementation SideMenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    viewNameArray = [[NSArray alloc]initWithObjects:@"Maps",@"Logout",nil];
    self.sideMenuTableView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleWidth;
    self.sideMenuTableView.backgroundColor = [UIColor clearColor];
    self.sideMenuTableView.backgroundView = nil;
    self.sideMenuTableView.bounces = NO;
    
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [self.sideMenuTableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return viewNameArray.count;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *simpleTableIdentifier = @"SimpleTableCell";
    
    SideMenuTableViewCell *cell = (SideMenuTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SideMenuTableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.viewNameLabel.text = [viewNameArray objectAtIndex:indexPath.row];
    cell.backgroundView = nil;
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 120;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 54;
}


-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIImageView *view = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 18)];
    
    
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0,100, 18)];
    imageView.image = [UIImage imageNamed:@"SliderBg.jpg"];
    
    pictureView = [[FBSDKProfilePictureView alloc]initWithFrame:CGRectMake(30, 50,60, 60)];
    
    [self facebookProfilePicture];
    [self googleProfilePic];
    
    if(googleImageView.image)
    [view addSubview:googleImageView];
    if(pictureView.profileID)
    [view addSubview:pictureView];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(100, 50, tableView.frame.size.width, 44)];
    [label setFont:[UIFont boldSystemFontOfSize:14]];
    NSString *string = loggedInUserName;
    [label setText:string];
    [view addSubview:label];
    
    UIImageView *profilePicImageView = [[UIImageView alloc]initWithFrame:CGRectMake(30, 50,40, 40)];
    profilePicImageView.layer.borderWidth = 1.0;
    profilePicImageView.layer.borderColor = [UIColor whiteColor].CGColor;
    profilePicImageView.layer.cornerRadius = (profilePicImageView.frame.size.width / 2) ;
    profilePicImageView.clipsToBounds = YES;
    
    
    [view setBackgroundColor:[UIColor colorWithRed:166/255.0 green:177/255.0 blue:186/255.0 alpha:1.0]];
    //your background color...
    return view;
}

-(void)facebookProfilePicture{
    
    FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
                                  initWithGraphPath:@"/me"
                                  parameters:@{ @"fields": @"id,name,picture",}
                                  HTTPMethod:@"GET"];
    [request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
        
        if([result objectForKey:@"id"]){
            NSString *imageStringOfLoginUser = [[[result valueForKey:@"picture"] valueForKey:@"data"] valueForKey:@"url"];
            
            url = [NSURL URLWithString:imageStringOfLoginUser];
            loggedInUserName = [result valueForKey:@"name"];
            pictureView.profileID = [result objectForKey:@"id"];

        }
        
        
    }];
}

-(void)googleProfilePic{
    
    
    if([[GIDSignIn sharedInstance] currentUser].userID){
        
        if ([[[GIDSignIn sharedInstance] currentUser].profile hasImage]) {
            
            NSURL *urlLink = [[[GIDSignIn sharedInstance] currentUser].profile imageURLWithDimension:100];
            
            NSData *imageData = [NSData dataWithContentsOfURL:urlLink];
            googleImageView = [[UIImageView alloc]initWithFrame:CGRectMake(30, 50,60, 60)];
            
            
        }
    }
    
    
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
