//
//  AppDelegate.h
//  DemoAppSep
//
//  Created by RanbijaySinghDeo on 03/09/15.
//  Copyright (c) 2015 RanbijaySinghDeo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "RESideMenu.h"
#import <Google/SignIn.h>


@import GoogleMaps;

@interface AppDelegate : UIResponder <UIApplicationDelegate,RESideMenuDelegate,GIDSignInDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;


@end

