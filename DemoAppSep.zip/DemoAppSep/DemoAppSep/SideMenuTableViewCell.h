//
//  SideMenuTableViewCell.h
//  DemoAppSep
//
//  Created by RanbijaySinghDeo on 04/09/15.
//  Copyright (c) 2015 RanbijaySinghDeo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SideMenuTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *viewNameLabel;

@end
