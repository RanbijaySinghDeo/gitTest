//
//  MapViewController.m
//  DemoAppSep
//
//  Created by RanbijaySinghDeo on 03/09/15.
//  Copyright (c) 2015 RanbijaySinghDeo. All rights reserved.
//

#import "MapViewController.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <QuartzCore/QuartzCore.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "SideMenuViewController.h"


@import GoogleMaps;

@interface MapViewController ()<FBSDKLoginButtonDelegate>

@end

@implementation MapViewController{
    //GMSMapView *mapView_;
    BOOL firstLocationUpdate_;
    UIButton *shareButton;
    CLLocation *location ;
    NSArray *shareArray;

}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.fbProfilePic.layer.borderWidth = 1.0;
    self.fbProfilePic.layer.borderColor = [UIColor whiteColor].CGColor;
    self.fbProfilePic.layer.cornerRadius = (self.fbProfilePic.frame.size.width / 2) ;
    self.fbProfilePic.clipsToBounds = YES;
    
    
    FBSDKLoginButton *fbLogingButton = [[FBSDKLoginButton alloc]init];
    fbLogingButton.delegate = self;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:fbLogingButton];
    
    [self.navigationItem setHidesBackButton:YES animated:YES];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Left"
                                                                             style:UIBarButtonItemStylePlain
                                                                            target:self
                                                                            action:@selector(presentLeftMenuViewController:)];
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:self.view.bounds];
    imageView.contentMode = UIViewContentModeScaleAspectFill;
    imageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    imageView.image = [UIImage imageNamed:@"Balloon"];
    [self.view addSubview:imageView];
    
    //    [self facebookProfilePicture];
    

    
//    [self.view addSubview:shareButton];
    
    [self googleMapPresentLocation];
    [self.mapView clear];
    
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    
    
    [self facebookProfilePicture];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)googleMapPresentLocation{
    
    
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:-33.868
                                                            longitude:151.2086
                                                                 zoom:12];
    
//    mapView_ = [GMSMapView mapWithFrame:CGRectZero camera:camera];
 //   mapView_ = [GMSMapView mapWithFrame:self.view.frame camera:camera];
    [self.mapView setCamera:camera];
    self.mapView.settings.compassButton = YES;
    self.mapView.settings.myLocationButton = YES;
    
    // Listen to the myLocation property of GMSMapView.
    [self.mapView addObserver:self
               forKeyPath:@"myLocation"
                  options:NSKeyValueObservingOptionNew
                  context:NULL];
    [self.view addSubview:self.mapView];
    [self.mapView addSubview:self.shareBUtton];
    

    // Ask for My Location data after the map has already been added to the UI.
    dispatch_async(dispatch_get_main_queue(), ^{
        self.mapView.myLocationEnabled = YES;
    });
    
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [self.mapView removeObserver:self forKeyPath:@"myLocation" context:nil];
}
- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary *)change
                       context:(void *)context {
    //if (!firstLocationUpdate_) {
    // If the first location update has not yet been recieved, then jump to that
    // location.
    firstLocationUpdate_ = YES;
    location = [change objectForKey:NSKeyValueChangeNewKey];
    //mapView_.camera = [GMSCameraPosition cameraWithTarget:location.coordinate
    //zoom:14];
    
    [self setMapToDeviceLocationAsCenter:location.coordinate];
    
    // }
}

-(void)setMapToDeviceLocationAsCenter:(CLLocationCoordinate2D)selectedCoordinate

{
    
    float radius = 1*1000; //radius in meters (25km)
    
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(selectedCoordinate, radius*2, radius*2);
    
    CLLocationCoordinate2D  northEast = CLLocationCoordinate2DMake(region.center.latitude - region.span.latitudeDelta/2, region.center.longitude - region.span.longitudeDelta/2);
    
    CLLocationCoordinate2D  southWest = CLLocationCoordinate2DMake(region.center.latitude + region.span.latitudeDelta/2, region.center.longitude + region.span.longitudeDelta/2);
    
    GMSCoordinateBounds* bounds = [[GMSCoordinateBounds alloc] initWithCoordinate:northEast coordinate:southWest];
    
    
    
    [self.mapView animateWithCameraUpdate:[GMSCameraUpdate fitBounds:bounds withPadding:10.0f]];
    
    
    
}

-(void)facebookProfilePicture{
    
    FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
                                  initWithGraphPath:@"/me"
                                  parameters:@{ @"fields": @"id,name,picture",}
                                  HTTPMethod:@"GET"];
    [request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
        
        NSString *imageStringOfLoginUser = [[[result valueForKey:@"picture"] valueForKey:@"data"] valueForKey:@"url"];
        
    }];
}
-(void)loginButtonDidLogOut:(FBSDKLoginButton *)loginButton{
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (IBAction)shareUserLocation:(id)sender {
    shareArray = [[NSArray alloc]initWithObjects:location,nil];
    UIActivityViewController *controller = [[UIActivityViewController alloc] initWithActivityItems:shareArray applicationActivities:nil];
    controller.excludedActivityTypes = @[];

    [self presentViewController:controller animated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
