//
//  ViewController.h
//  DemoAppSep
//
//  Created by RanbijaySinghDeo on 03/09/15.
//  Copyright (c) 2015 RanbijaySinghDeo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <Google/SignIn.h>


@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *facebookLoginButtonView;
@property (weak, nonatomic) IBOutlet FBSDKLoginButton *fbLogingButton;
@property(weak, nonatomic) IBOutlet GIDSignInButton *signInButton;


@end

