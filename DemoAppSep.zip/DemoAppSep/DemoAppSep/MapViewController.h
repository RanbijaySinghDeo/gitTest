//
//  MapViewController.h
//  DemoAppSep
//
//  Created by RanbijaySinghDeo on 03/09/15.
//  Copyright (c) 2015 RanbijaySinghDeo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RESideMenu.h"
#import <Google/SignIn.h>
#import <MapKit/MapKit.h>
#import <GoogleMaps/GoogleMaps.h>
@interface MapViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *fbProfilePic;
@property (weak, nonatomic) IBOutlet UILabel *loggedInUserLabel;

@property (weak, nonatomic) IBOutlet UIButton *shareBUtton;
@property (weak, nonatomic) IBOutlet GMSMapView *mapView;
@end
